package com.guardian.anticheat.protocol;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import com.guardian.anticheat.GuardianAC;
import com.guardian.anticheat.manager.PlayerData;
import org.bukkit.entity.Player;

/**
 * ProtocolLib orqali paket darajasida tekshiruv. Bu "invalid rotation" check -
 * vanilla Minecraft klienti pitch qiymatini HECH QACHON -90..90 oralig'idan
 * tashqariga chiqarmaydi. Agar bunday paket kelsa, demak klient modifikatsiya
 * qilingan (masalan ba'zi KillAura/Freecam turlari xato rotatsiya yuboradi).
 * Bu deyarli 0% false-positive beradigan eng ishonchli signallardan biri.
 */
public class ProtocolHookManager {

    private final GuardianAC plugin;

    public ProtocolHookManager(GuardianAC plugin) {
        this.plugin = plugin;
    }

    public void register() {
        ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(
                plugin, ListenerPriority.NORMAL,
                PacketType.Play.Client.LOOK,
                PacketType.Play.Client.POSITION_LOOK) {

            @Override
            public void onPacketReceiving(PacketEvent event) {
                if (!plugin.getConfig().getBoolean("checks.invalid-rotation.enabled", true)) return;

                Player player = event.getPlayer();
                if (player == null || player.hasPermission("guardianac.bypass")) return;

                try {
                    float pitch = event.getPacket().getFloat().read(1); // yaw=0, pitch=1 (POSITION_LOOK/LOOK packet layout)
                    float yaw = event.getPacket().getFloat().read(0);

                    boolean invalidPitch = pitch > 90.5f || pitch < -90.5f || Float.isNaN(pitch);
                    boolean invalidYaw = Float.isNaN(yaw) || Float.isInfinite(yaw);

                    if (invalidPitch || invalidYaw) {
                        plugin.getViolationManager().flag(player, PlayerData.CheckType.INVALID_ROTATION, 2,
                                "noto'g'ri paket: pitch=" + pitch + " yaw=" + yaw);
                    }
                } catch (Exception ignored) {
                    // Paket strukturasi versiyaga qarab farq qilishi mumkin - xato bo'lsa jim o'tkazamiz
                }
            }
        });
    }
}
