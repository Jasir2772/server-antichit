package com.guardian.anticheat.manager;

import com.guardian.anticheat.GuardianAC;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.BanList;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class PunishmentManager {

    private final GuardianAC plugin;
    // Bir xil bosqichni takror qo'llamaslik uchun (checkType+player -> oxirgi bosqich foizi)
    private final Map<String, Double> lastStage = new HashMap<>();

    public PunishmentManager(GuardianAC plugin) {
        this.plugin = plugin;
    }

    public void evaluate(Player player, PlayerData.CheckType type, double percent) {
        List<Map<?, ?>> stages = plugin.getConfig().getMapList("punishments.stages");
        String key = player.getUniqueId() + ":" + type.name();
        double last = lastStage.getOrDefault(key, -1.0);

        // Eng yuqori mos keladigan bosqichni topamiz
        Map<?, ?> best = null;
        double bestThreshold = -1;
        for (Map<?, ?> stage : stages) {
            double threshold = ((Number) stage.get("vl-percent")).doubleValue();
            if (percent >= threshold && threshold > bestThreshold) {
                best = stage;
                bestThreshold = threshold;
            }
        }

        if (best == null || bestThreshold <= last) {
            return; // hali shu bosqichga yetmagan yoki avval qo'llanilgan
        }

        lastStage.put(key, bestThreshold);
        String action = String.valueOf(best.get("action"));
        String message = ChatColor.translateAlternateColorCodes('&', String.valueOf(best.get("message")));

        switch (action) {
            case "WARN" -> player.sendMessage(message);
            case "KICK" -> plugin.getServer().getScheduler().runTask(plugin, () -> player.kickPlayer(message));
            case "BAN" -> {
                int hours = best.containsKey("ban-duration-hours") ? ((Number) best.get("ban-duration-hours")).intValue() : 0;
                Date expiry = hours > 0 ? new Date(System.currentTimeMillis() + hours * 3600_000L) : null;
                String playerName = player.getName();

                // Avval dramatik effektni ko'rsatamiz, so'ng haqiqiy ban/kick bajariladi
                plugin.getBanEffectManager().playAndThenPunish(player, () -> {
                    plugin.getServer().getBanList(BanList.Type.NAME).addBan(
                            playerName, "GuardianAC: " + type.name() + " aniqlandi", expiry, "GuardianAC");
                    if (player.isOnline()) {
                        player.kickPlayer(message);
                    }
                    plugin.getLogger().warning(playerName + " ban qilindi: " + type.name());
                });
            }
            default -> plugin.getLogger().warning("Noma'lum jazo turi config.yml da: " + action);
        }
    }

    public void resetStages(UUID uuid) {
        lastStage.keySet().removeIf(k -> k.startsWith(uuid.toString()));
    }
}
