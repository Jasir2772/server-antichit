package com.guardian.anticheat.manager;

import org.bukkit.Location;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.EnumMap;
import java.util.Map;
import java.util.UUID;

/** Har bir o'yinchi uchun tekshiruv holatini saqlaydi. */
public class PlayerData {

    public enum CheckType { FLY, SPEED, NOFALL, KILLAURA, REACH, AUTOCLICKER, XRAY, INVALID_ROTATION }

    private final UUID uuid;
    private final Map<CheckType, Integer> violations = new EnumMap<>(CheckType.class);
    private final Map<CheckType, Integer> streaks = new EnumMap<>(CheckType.class);

    // Harakat holati
    public Location lastLocation;
    public long lastMoveTime;
    public double lastFallDistance;
    public boolean wasOnGround = true;

    // Jang holati
    public final Deque<Long> recentClickTimes = new ArrayDeque<>();
    public long lastAttackTime;
    public float lastYaw;
    public float lastPitch;

    // X-Ray statistikasi
    public int totalMined;
    public int valuableMined;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        for (CheckType type : CheckType.values()) {
            violations.put(type, 0);
            streaks.put(type, 0);
        }
    }

    /** Ketma-ket shubhali namunalar soni (false-positive filtri uchun). */
    public int getStreak(CheckType type) {
        return streaks.getOrDefault(type, 0);
    }

    public int incrementStreak(CheckType type) {
        int val = getStreak(type) + 1;
        streaks.put(type, val);
        return val;
    }

    public void clearStreak(CheckType type) {
        streaks.put(type, 0);
    }

    public UUID getUuid() {
        return uuid;
    }

    public int getVl(CheckType type) {
        return violations.getOrDefault(type, 0);
    }

    public void addVl(CheckType type, int amount) {
        violations.merge(type, amount, Integer::sum);
    }

    public void decay(CheckType type, int amount) {
        int current = getVl(type);
        if (current > 0) {
            violations.put(type, Math.max(0, current - amount));
        }
    }

    public void resetVl(CheckType type) {
        violations.put(type, 0);
    }

    public void resetAll() {
        for (CheckType type : CheckType.values()) {
            violations.put(type, 0);
        }
    }
}
