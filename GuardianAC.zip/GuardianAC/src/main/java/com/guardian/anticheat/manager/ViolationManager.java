package com.guardian.anticheat.manager;

import com.guardian.anticheat.GuardianAC;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ViolationManager {

    private final GuardianAC plugin;
    private final Map<UUID, PlayerData> dataMap = new ConcurrentHashMap<>();

    public ViolationManager(GuardianAC plugin) {
        this.plugin = plugin;
    }

    public PlayerData getData(Player player) {
        return dataMap.computeIfAbsent(player.getUniqueId(), PlayerData::new);
    }

    public void removeData(Player player) {
        dataMap.remove(player.getUniqueId());
    }

    /**
     * Bitta shubhali namunani ro'yxatga oladi, lekin DARHOL VL qo'shmaydi.
     * Faqat bir xil check ketma-ket "confirmations" marta (config dan) shubhali
     * chiqsagina haqiqiy VL qo'shiladi. Bu lag-spike, internet uzilishi yoki
     * bitta tasodifiy holatdan yolg'on ban berilishining oldini oladi.
     */
    public void suspect(Player player, PlayerData.CheckType type, int vlAmount, String reason) {
        PlayerData data = getData(player);
        int required = plugin.getConfig().getInt("checks." + configKey(type) + ".confirmations", 3);
        int streak = data.incrementStreak(type);

        if (streak >= required) {
            flag(player, type, vlAmount, reason + " (tasdiqlandi: " + streak + "/" + required + ")");
            // To'liq nollamaymiz - qisman kamaytiramiz, shunda davomli cheat tezroq ushlanadi
            data.clearStreak(type);
        }
    }

    /** Toza (shubhasiz) namuna kelganda streak'ni tozalaydi. */
    public void clearStreak(Player player, PlayerData.CheckType type) {
        getData(player).clearStreak(type);
    }

    /**
     * VL qo'shadi, staff'ga xabar beradi va agar max-vl chegarasidan
     * oshsa PunishmentManager orqali jazo qo'llaydi.
     */
    public void flag(Player player, PlayerData.CheckType type, int vlAmount, String reason) {
        PlayerData data = getData(player);
        data.addVl(type, vlAmount);
        int currentVl = data.getVl(type);
        int maxVl = plugin.getConfig().getInt("checks." + configKey(type) + ".max-vl", 10);

        if (plugin.getConfig().getBoolean("settings.alert-staff", true)) {
            String msg = ChatColor.RED + "[GuardianAC] " + ChatColor.YELLOW + player.getName()
                    + ChatColor.GRAY + " -> " + ChatColor.GOLD + type.name()
                    + ChatColor.GRAY + " (" + currentVl + "/" + maxVl + ") " + ChatColor.WHITE + reason;
            for (Player staff : plugin.getServer().getOnlinePlayers()) {
                if (staff.hasPermission("guardianac.alerts")) {
                    staff.sendMessage(msg);
                }
            }
            plugin.getLogger().info(ChatColor.stripColor(msg));
        }

        double percent = Math.min(100.0, (currentVl / (double) maxVl) * 100.0);
        plugin.getPunishmentManager().evaluate(player, type, percent);
    }

    private String configKey(PlayerData.CheckType type) {
        return switch (type) {
            case FLY -> "fly";
            case SPEED -> "speed";
            case NOFALL -> "nofall";
            case KILLAURA -> "killaura";
            case REACH -> "reach";
            case AUTOCLICKER -> "autoclicker";
            case XRAY -> "xray";
            case INVALID_ROTATION -> "invalid-rotation";
        };
    }

    /** Har necha sekundda VL larni asta-sekin pasaytiradi (false-positive larni kamaytirish uchun). */
    public void startDecayTask() {
        long period = 20L * Math.max(10, plugin.getConfig().getInt("settings.violation-decay-seconds", 120));
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            for (PlayerData data : dataMap.values()) {
                for (PlayerData.CheckType type : PlayerData.CheckType.values()) {
                    data.decay(type, 1);
                }
            }
        }, period, period);
    }
}
