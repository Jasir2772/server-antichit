# GuardianAC — Paper 1.20.4 Anticheat

## O'rnatish
1. Java 17+ va Maven o'rnatilgan bo'lishi kerak.
2. Loyiha papkasida: `mvn clean package`
3. `target/GuardianAC.jar` faylini serveringizning `plugins/` papkasiga qo'ying.
4. Serverni qayta ishga tushiring. `plugins/GuardianAC/config.yml` orqali sozlang.

## Buyruqlar
- `/gac reload` — configni qayta yuklaydi
- `/gac check <player>` yoki `/gac vl <player>` — o'yinchining VL (violation level) larini ko'rsatadi
- `/gac reset <player>` — o'yinchining barcha VL larini tozalaydi

## Huquqlar
- `guardianac.admin` — buyruqlarni ishlatish (default: op)
- `guardianac.alerts` — real vaqtda shubhali harakat xabarlarini olish (default: op)
- `guardianac.bypass` — barcha tekshiruvlardan chetlab o'tish (masalan, staff uchun)

## 🛡️ Yolg'on ban (false-positive) himoyasi
Har bir harakat-asosli check endi **"confirmations"** tizimidan foydalanadi: bitta
shubhali holat DARHOL VL bermaydi. Bir xil check ketma-ket bir necha marta (config
dagi `confirmations` qiymati, odatda 3-4) shubhali chiqishi kerak, aks holda streak
tozalanadi. Bu lag-spike, internet tebranishi yoki tasodifiy bir martalik holatdan
begunoh o'yinchiga ban berilishining oldini oladi. `NoFall` va `X-Ray` kabi
diskret/namuna-asoslangan checklar `confirmations: 1` bilan qoladi, chunki ular
allaqachon boshqa yo'l bilan tasdiqlangan.

Qo'shimcha tavsiyalar:
- Ishga tushirgandan keyin bir necha kun `settings.alert-staff: true` bilan kuzating,
  keyin `punishments.stages` dagi foizlarni real natijalarga qarab moslang.
- Yangi qo'shilgan **Invalid-Rotation** check (ProtocolLib orqali) amalda deyarli
  0% false-positive beradi, chunki vanilla klient bunday paket hech qachon yubormaydi.

## 💀 Ban effekti (animatsiya)
Endi o'yinchi **BAN** bosqichiga yetganda:
1. O'yinchi tepaga otiladi (`ban-effect.launch-power`)
2. Inventaridagi buyumlar atrofga sochiladi (`ban-effect.scatter-items`)
3. Bulut zarrachalari + dramatik ovoz (Ender Dragon growl) ijro etiladi
4. Ekranda qizil "BAN" title chiqadi
5. `duration-ticks` (default 30 tick = 1.5s) dan keyin haqiqiy ban+kick bajariladi

Bularning barchasi `config.yml` dagi `ban-effect:` bo'limidan sozlanadi (yoqish/o'chirish,
kuch, zarracha turi, ovoz, davomiylik).

## ProtocolLib bilan kengaytirilgan tekshiruv (ixtiyoriy, lekin tavsiya etiladi)
[ProtocolLib](https://www.spigotmc.org/resources/protocollib.1997/) ni `plugins/`
papkasiga qo'ysangiz, GuardianAC avtomatik ravishda **Invalid-Rotation** checkni
yoqadi: bu paket darajasida yaw/pitch qiymatlarining vanilla klient hech qachon
yubormaydigan darajada noto'g'ri (masalan pitch 90° dan tashqari yoki NaN)
ekanini tekshiradi — bu deyarli 100% ishonchli hack signali. ProtocolLib bo'lmasa
ham qolgan barcha checklar (Fly, Speed, NoFall, KillAura, Reach, AutoClicker,
X-Ray) to'liq ishlayveradi.

## Nima aniqlanadi va qanday
| Cheat | Usul | Ishonchlilik |
|---|---|---|
| **Fly** | Vertikal tezlik + yerga yaqinlik tahlili | Yuqori |
| **Speed** | Gorizontal tezlik tick-normallashtirilgan holda | Yuqori |
| **NoFall** | Fall-damage o'tkazib yuborilishini kuzatish | O'rta-yuqori |
| **KillAura** | Qarash burchagi + hujum chastotasi | Yuqori |
| **Reach** | Hujum masofasi (max ~3.3 blok) | Yuqori |
| **AutoClicker** | CPS chegarasi + klik interval dispersiyasi | O'rta-yuqori |
| **X-Ray** | Qimmatli ruda / umumiy qazish nisbati (heuristik) | **O'rta** — dalil emas, signal |
| **Invalid-Rotation** *(ProtocolLib kerak)* | Vanilla-klient bera olmaydigan pitch/yaw qiymatlari | **Juda yuqori** (~100%) |

## ⚠️ ESP va Freecam haqida muhim eslatma
Bu ikkalasi **sof klient-tomon** effektlar: ESP o'yinchining ekranida devor orqali
his-belgi chizadi, freecam esa kamerani tanadan ajratib boshqaradi — ikkalasi ham
serverga hech qanday "noto'g'ri" ma'lumot yubormaydi, shuning uchun oddiy Paper/Bukkit
API bilan ularni **ishonchli tarzda** aniqlash imkonsiz.

Buni real darajada aniqlash uchun quyidagilar kerak:
- **ProtocolLib** — paketlarni past darajada tahlil qilish (masalan, ESP client'lar
  ba'zan entity metadata so'rovlarini g'ayrioddiy tarzda ishlatadi; freecam esa
  ba'zida player pozitsiyasi bilan kamera pozitsiyasi orasidagi nomuvofiqlikni
  ProtocolLib orqali payqash mumkin bo'lgan paket naqshlarini yaratadi).
- **NCP/Vulcan/Grim kabi ochiq manba anticheatlar** — bu loyihalar yillar davomida
  ishlab chiqilgan va ProtocolLib asosida ancha chuqur tahlil qiladi. Agar sizga
  chinakam kuchli anticheat kerak bo'lsa, GrimAC (https://github.com/GrimAnticheat/Grim)
  kabi ochiq loyihalarni o'rganish yoki ular bilan birga ishlatish tavsiya etiladi.
- Ba'zi serverlar ESP/freecam o'rniga **shubhali natijalarga** e'tibor beradi: masalan,
  o'yinchi doim to'g'ridan-to'g'ri (devor ortidagi) o'yinchiga qarab yuradi — buni
  qo'shimcha check sifatida yozish mumkin, lekin false-positive darajasi yuqori bo'ladi.

Xohlasangiz, keyingi bosqichda ProtocolLib integratsiyasini yoki GrimAC bilan
moslashtirilgan qo'shimcha modulni ham qo'shib beraman.

## Sozlash maslahatlari
- Har bir check `config.yml` da `enabled: true/false` bilan o'chirilishi/yoqilishi mumkin.
- False-positive ko'p bo'lsa: `max-vl` ni oshiring yoki `violation-decay-seconds` ni kamaytiring.
- Jazo bosqichlarini (`punishments.stages`) o'zingizga moslab o'zgartiring — WARN/KICK/BAN
  foizlarini xohlagancha sozlash mumkin.
