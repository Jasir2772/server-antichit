package com.guardian.anticheat.listeners;

import com.guardian.anticheat.GuardianAC;
import com.guardian.anticheat.manager.PlayerData;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.Deque;

public class CombatListener implements Listener {

    private final GuardianAC plugin;

    public CombatListener(GuardianAC plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onAttack(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof LivingEntity target)) return;
        if (attacker.hasPermission("guardianac.bypass")) return;

        PlayerData data = plugin.getViolationManager().getData(attacker);
        long now = System.currentTimeMillis();

        // ---------- REACH CHECK ----------
        if (plugin.getConfig().getBoolean("checks.reach.enabled", true)) {
            double distance = attacker.getEyeLocation().distance(target.getLocation());
            double maxDistance = plugin.getConfig().getDouble("checks.reach.max-distance", 3.3);
            if (distance > maxDistance) {
                plugin.getViolationManager().suspect(attacker, PlayerData.CheckType.REACH, 2,
                        "masofa: " + String.format("%.2f", distance) + " blok");
            } else {
                plugin.getViolationManager().clearStreak(attacker, PlayerData.CheckType.REACH);
                data.decay(PlayerData.CheckType.REACH, 1);
            }
        }

        // ---------- KILLAURA CHECK (burchak asosida) ----------
        if (plugin.getConfig().getBoolean("checks.killaura.enabled", true)) {
            Vector toTarget = target.getLocation().toVector().subtract(attacker.getEyeLocation().toVector()).normalize();
            Vector look = attacker.getEyeLocation().getDirection().normalize();
            double dot = Math.max(-1.0, Math.min(1.0, look.dot(toTarget)));
            double angleDeg = Math.toDegrees(Math.acos(dot));
            double maxAngle = plugin.getConfig().getDouble("checks.killaura.max-attack-angle", 90);

            if (angleDeg > maxAngle) {
                plugin.getViolationManager().suspect(attacker, PlayerData.CheckType.KILLAURA, 2,
                        "nishonga qaramasdan urish, burchak: " + String.format("%.1f", angleDeg) + "°");
            } else {
                plugin.getViolationManager().clearStreak(attacker, PlayerData.CheckType.KILLAURA);
                data.decay(PlayerData.CheckType.KILLAURA, 1);
            }

            // Hujumlar chastotasi (multi-aura / super-fast switching belgisi)
            long lastAttack = data.lastAttackTime;
            data.lastAttackTime = now;
            if (lastAttack != 0 && (now - lastAttack) < 30) {
                plugin.getViolationManager().suspect(attacker, PlayerData.CheckType.KILLAURA, 2,
                        "hujumlar orasidagi vaqt g'ayritabiiy qisqa: " + (now - lastAttack) + "ms");
            }
        }

        // ---------- AUTOCLICKER / CPS CHECK ----------
        if (plugin.getConfig().getBoolean("checks.autoclicker.enabled", true)) {
            Deque<Long> clicks = data.recentClickTimes;
            clicks.addLast(now);
            while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) {
                clicks.pollFirst();
            }
            int cps = clicks.size();
            int maxCps = plugin.getConfig().getInt("checks.autoclicker.max-cps", 18);

            if (cps > maxCps) {
                plugin.getViolationManager().suspect(attacker, PlayerData.CheckType.AUTOCLICKER, 2,
                        "CPS: " + cps);
            }

            if (plugin.getConfig().getBoolean("checks.autoclicker.pattern-check", true) && clicks.size() >= 6) {
                if (isSuspiciouslyRegular(clicks)) {
                    plugin.getViolationManager().suspect(attacker, PlayerData.CheckType.AUTOCLICKER, 2,
                            "bir xil intervalli klik naqshi (bot ehtimoli)");
                }
            }
        }
    }

    /** Klik intervallari orasidagi dispersiyani tekshiradi - inson qo'li deyarli har doim
     * biroz tebranadi, bot esa juda barqaror interval beradi. */
    private boolean isSuspiciouslyRegular(Deque<Long> clicks) {
        Long[] arr = clicks.toArray(new Long[0]);
        if (arr.length < 6) return false;
        double[] intervals = new double[arr.length - 1];
        for (int i = 1; i < arr.length; i++) {
            intervals[i - 1] = arr[i] - arr[i - 1];
        }
        double mean = 0;
        for (double v : intervals) mean += v;
        mean /= intervals.length;

        double variance = 0;
        for (double v : intervals) variance += Math.pow(v - mean, 2);
        variance /= intervals.length;
        double stdDev = Math.sqrt(variance);

        // Juda past standart og'ish (< 8ms) va yetarlicha tez klik - shubhali
        return stdDev < 8.0 && mean < 120;
    }
}
