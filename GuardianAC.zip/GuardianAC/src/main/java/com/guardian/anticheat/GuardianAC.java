package com.guardian.anticheat;

import com.guardian.anticheat.commands.AnticheatCommand;
import com.guardian.anticheat.listeners.CombatListener;
import com.guardian.anticheat.listeners.MovementListener;
import com.guardian.anticheat.listeners.WorldListener;
import com.guardian.anticheat.manager.BanEffectManager;
import com.guardian.anticheat.manager.PunishmentManager;
import com.guardian.anticheat.manager.ViolationManager;
import com.guardian.anticheat.protocol.ProtocolHookManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class GuardianAC extends JavaPlugin {

    private static GuardianAC instance;
    private ViolationManager violationManager;
    private PunishmentManager punishmentManager;
    private BanEffectManager banEffectManager;
    private ProtocolHookManager protocolHookManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.violationManager = new ViolationManager(this);
        this.punishmentManager = new PunishmentManager(this);
        this.banEffectManager = new BanEffectManager(this);

        getServer().getPluginManager().registerEvents(new MovementListener(this), this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new WorldListener(this), this);

        var cmd = getCommand("guardianac");
        if (cmd != null) {
            AnticheatCommand executor = new AnticheatCommand(this);
            cmd.setExecutor(executor);
            cmd.setTabCompleter(executor);
        }

        violationManager.startDecayTask();

        if (getServer().getPluginManager().isPluginEnabled("ProtocolLib")) {
            this.protocolHookManager = new ProtocolHookManager(this);
            protocolHookManager.register();
            getLogger().info("ProtocolLib topildi -> paket-darajasidagi qo'shimcha tekshiruvlar (invalid rotation) yoqildi.");
        } else {
            getLogger().warning("ProtocolLib topilmadi. Asosiy checklar (Fly, Speed, KillAura, Reach, AutoClicker, X-Ray, NoFall) baribir ishlayveradi,");
            getLogger().warning("lekin paket-darajasidagi eng ishonchli tekshiruv (invalid-rotation) va ESP/Freecam uchun kengaytirilgan imkoniyatlar uchun");
            getLogger().warning("https://www.spigotmc.org/resources/protocollib.1997/ dan ProtocolLib ni o'rnatib qo'yishni tavsiya qilamiz.");
        }

        getLogger().info("GuardianAC yoqildi. Checklar: Fly, Speed, NoFall, KillAura, Reach, AutoClicker, X-Ray" +
                (protocolHookManager != null ? ", Invalid-Rotation" : ""));
        getLogger().warning("ESLATMA: ESP ni server-tomondan 100% aniqlash klient-o'zgartirish hisoblanmaydi; freecam ham asosan vizual. README ga qarang.");
    }

    @Override
    public void onDisable() {
        getLogger().info("GuardianAC o'chirildi.");
    }

    public static GuardianAC getInstance() {
        return instance;
    }

    public ViolationManager getViolationManager() {
        return violationManager;
    }

    public PunishmentManager getPunishmentManager() {
        return punishmentManager;
    }

    public BanEffectManager getBanEffectManager() {
        return banEffectManager;
    }
}
