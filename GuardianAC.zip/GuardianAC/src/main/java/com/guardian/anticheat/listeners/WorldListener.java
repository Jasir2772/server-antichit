package com.guardian.anticheat.listeners;

import com.guardian.anticheat.GuardianAC;
import com.guardian.anticheat.manager.PlayerData;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * X-Ray ni 100% aniqlash mumkin emas (o'yinchi baribir qazadi, bu qonuniy amal).
 * Buning o'rniga statistik heuristika ishlatiladi: agar o'yinchi qimmatli rudalarni
 * (olmos, ancient debris va h.k.) atrofdagi bloklarni ochmasdan, juda yuqori nisbatda
 * va to'g'ridan-to'g'ri topsa - bu shubhali xatti-harakat sifatida belgilanadi.
 * Bu 100% dalil emas, balki tergov uchun signal - qo'lda tekshirish tavsiya etiladi.
 */
public class WorldListener implements Listener {

    private final GuardianAC plugin;
    private final Set<Material> trackedOres = new HashSet<>();

    public WorldListener(GuardianAC plugin) {
        this.plugin = plugin;
        reloadOreList();
    }

    public void reloadOreList() {
        trackedOres.clear();
        List<String> names = plugin.getConfig().getStringList("checks.xray.tracked-ores");
        for (String name : names) {
            try {
                trackedOres.add(Material.valueOf(name));
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Noma'lum material config.yml da: " + name);
            }
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (!plugin.getConfig().getBoolean("checks.xray.enabled", true)) return;
        Player player = event.getPlayer();
        if (player.hasPermission("guardianac.bypass")) return;
        // Faqat yer osti (Y < 64, tog' osti) qazishlarni hisobga olamiz
        if (event.getBlock().getY() > 64) return;

        PlayerData data = plugin.getViolationManager().getData(player);
        data.totalMined++;

        if (trackedOres.contains(event.getBlock().getType())) {
            // Atrofida qancha bo'sh/havo blok borligini tekshiramiz - agar rudaga
            // to'g'ridan-to'g'ri "tunnel" qazmasdan tez-tez tushib qolsa, shubha ortadi
            data.valuableMined++;
        }

        int minSample = plugin.getConfig().getInt("checks.xray.min-blocks-sample", 40);
        if (data.totalMined >= minSample) {
            double ratio = data.valuableMined / (double) data.totalMined;
            double threshold = plugin.getConfig().getDouble("checks.xray.suspicious-ratio", 0.35);
            if (ratio > threshold) {
                plugin.getViolationManager().flag(player, PlayerData.CheckType.XRAY, 3,
                        "qimmatli ruda nisbati g'ayritabiiy yuqori: " + String.format("%.0f%%", ratio * 100));
            }
            // Namunani qayta boshlaymiz, doimiy ravishda kuzatish uchun
            data.totalMined = 0;
            data.valuableMined = 0;
        }
    }
}
