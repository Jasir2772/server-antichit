package com.guardian.anticheat.manager;

import com.guardian.anticheat.GuardianAC;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/**
 * O'yinchi ban qilinishidan oldin ko'rsatiladigan dramatik effekt:
 * tepaga otiladi, buyumlari atrofga sochiladi, zarracha/ovoz effektlari
 * ijro etiladi, so'ng belgilangan vaqtdan keyin haqiqiy ban bajariladi.
 */
public class BanEffectManager {

    private final GuardianAC plugin;

    public BanEffectManager(GuardianAC plugin) {
        this.plugin = plugin;
    }

    public void playAndThenPunish(Player player, Runnable actualPunishment) {
        boolean enabled = plugin.getConfig().getBoolean("ban-effect.enabled", true);
        if (!enabled || !player.isOnline()) {
            actualPunishment.run();
            return;
        }

        int durationTicks = plugin.getConfig().getInt("ban-effect.duration-ticks", 30);
        double launchPower = plugin.getConfig().getDouble("ban-effect.launch-power", 2.6);
        boolean scatter = plugin.getConfig().getBoolean("ban-effect.scatter-items", true);

        Particle particle = parseParticle(plugin.getConfig().getString("ban-effect.particle", "CLOUD"));
        Sound sound = parseSound(plugin.getConfig().getString("ban-effect.sound", "ENTITY_ENDER_DRAGON_GROWL"));

        Location origin = player.getLocation();

        // 1) O'yinchini tepaga otish
        Vector launch = new Vector(
                (Math.random() - 0.5) * 0.6,
                launchPower,
                (Math.random() - 0.5) * 0.6
        );
        player.setVelocity(launch);
        player.setGliding(false);

        // 2) Buyumlarni atrofga sochish
        if (scatter) {
            for (ItemStack item : player.getInventory().getContents()) {
                if (item == null || item.getType().isAir()) continue;
                Location dropLoc = origin.clone().add(0, 1, 0);
                var dropped = player.getWorld().dropItem(dropLoc, item);
                dropped.setVelocity(new Vector(
                        (Math.random() - 0.5) * 1.2,
                        Math.random() * 0.6 + 0.2,
                        (Math.random() - 0.5) * 1.2
                ));
            }
            player.getInventory().clear();
        }

        if (sound != null) {
            player.getWorld().playSound(origin, sound, 1.5f, 0.8f);
        }

        player.sendTitle(net.md_5.bungee.api.ChatColor.translateAlternateColorCodes('&', "&4&lBAN"),
                net.md_5.bungee.api.ChatColor.translateAlternateColorCodes('&', "&cHack ishlatgani aniqlandi"), 5, durationTicks, 10);

        // 3) Effekt davomida zarrachalarni takroran chiqarish
        final Particle fx = particle;
        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (!player.isOnline() || ticks >= durationTicks) {
                    this.cancel();
                    if (player.isOnline()) {
                        actualPunishment.run();
                    } else {
                        // O'yinchi allaqachon chiqib ketgan bo'lsa ham jazoni qo'llaymiz (masalan ban-list ga qo'shish)
                        actualPunishment.run();
                    }
                    return;
                }
                if (fx != null) {
                    Location loc = player.getLocation();
                    player.getWorld().spawnParticle(fx, loc.clone().add(0, 1, 0), 12, 0.4, 0.6, 0.4, 0.01);
                }
                ticks += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private Particle parseParticle(String name) {
        try {
            return Particle.valueOf(name);
        } catch (Exception e) {
            return Particle.CLOUD;
        }
    }

    private Sound parseSound(String name) {
        try {
            return Sound.valueOf(name);
        } catch (Exception e) {
            return null;
        }
    }
}
