package com.guardian.anticheat.listeners;

import com.guardian.anticheat.GuardianAC;
import com.guardian.anticheat.manager.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public class MovementListener implements Listener {

    private final GuardianAC plugin;

    public MovementListener(GuardianAC plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        plugin.getViolationManager().removeData(e.getPlayer());
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        // Teleportdan keyingi bitta harakatni e'tiborsiz qoldirish uchun lastLocation ni yangilaymiz
        PlayerData data = plugin.getViolationManager().getData(e.getPlayer());
        data.lastLocation = e.getTo();
        data.lastMoveTime = System.currentTimeMillis();
    }

    @EventHandler
    public void onFallDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player player)) return;
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        // NoFall: agar o'yinchi kutilgan fall-damage dan qochsa (masalan onGround spoofing)
        // buni PlayerMoveEvent dagi fallDistance kuzatuvi bilan birga ishlatamiz
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (player.hasPermission("guardianac.bypass")) return;
        if (event.getFrom().getWorld() != event.getTo().getWorld()) return;

        PlayerData data = plugin.getViolationManager().getData(player);
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) return;

        long now = System.currentTimeMillis();
        if (data.lastLocation == null) {
            data.lastLocation = to;
            data.lastMoveTime = now;
            data.wasOnGround = player.isOnGround();
            return;
        }

        long dt = Math.max(1, now - data.lastMoveTime);
        // Faqat har ~50ms (1 tick) dan tez-tez kelgan hodisalarni ham hisobga olamiz, lekin
        // lag spike larni yumshatish uchun dt ni tick birligiga normallaymiz
        double ticks = Math.max(1.0, dt / 50.0);

        boolean exempt = player.getGameMode() == GameMode.CREATIVE
                || player.getGameMode() == GameMode.SPECTATOR
                || player.isFlying()
                || player.isGliding()
                || player.isInsideVehicle()
                || player.isSwimming()
                || player.getAllowFlight();

        // ---------- FLY CHECK ----------
        if (plugin.getConfig().getBoolean("checks.fly.enabled", true) && !exempt) {
            double dy = to.getY() - from.getY();
            double maxVertical = plugin.getConfig().getDouble("checks.fly.max-vertical-speed", 0.6) * ticks;
            boolean hasLevitation = player.hasPotionEffect(org.bukkit.potion.PotionEffectType.LEVITATION);
            boolean nearGround = player.isOnGround() || data.wasOnGround;

            if (dy > maxVertical + 0.35 && !nearGround && !hasLevitation) {
                plugin.getViolationManager().suspect(player, PlayerData.CheckType.FLY, 2,
                        "vertikal tezlik: " + String.format("%.2f", dy) + " blok/tick");
            } else {
                plugin.getViolationManager().clearStreak(player, PlayerData.CheckType.FLY);
                data.decay(PlayerData.CheckType.FLY, 1);
            }
        }

        // ---------- SPEED CHECK ----------
        if (plugin.getConfig().getBoolean("checks.speed.enabled", true) && !exempt) {
            double dx = to.getX() - from.getX();
            double dz = to.getZ() - from.getZ();
            double horizontalDist = Math.sqrt(dx * dx + dz * dz);
            double maxHorizontal = plugin.getConfig().getDouble("checks.speed.max-horizontal-speed", 0.6) * ticks;
            boolean hasSpeedEffect = player.hasPotionEffect(org.bukkit.potion.PotionEffectType.SPEED);
            double allowance = hasSpeedEffect ? maxHorizontal * 1.8 : maxHorizontal;

            if (horizontalDist > allowance + 0.4) {
                plugin.getViolationManager().suspect(player, PlayerData.CheckType.SPEED, 2,
                        "gorizontal tezlik: " + String.format("%.2f", horizontalDist) + " blok/tick");
            } else {
                plugin.getViolationManager().clearStreak(player, PlayerData.CheckType.SPEED);
                data.decay(PlayerData.CheckType.SPEED, 1);
            }
        }

        // ---------- NOFALL CHECK ----------
        if (plugin.getConfig().getBoolean("checks.nofall.enabled", true) && !exempt) {
            float fallDistance = player.getFallDistance();
            boolean landedSoft = player.isOnGround() && !data.wasOnGround && fallDistance == 0
                    && data.lastFallDistance > 3.0;
            if (landedSoft) {
                plugin.getViolationManager().flag(player, PlayerData.CheckType.NOFALL, 1,
                        "qulash zarari o'tkazib yuborilgan (fallDistance reset)");
            }
            data.lastFallDistance = fallDistance;
        }

        data.wasOnGround = player.isOnGround();
        data.lastLocation = to;
        data.lastMoveTime = now;
    }
}
