package com.guardian.anticheat.commands;

import com.guardian.anticheat.GuardianAC;
import com.guardian.anticheat.manager.PlayerData;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AnticheatCommand implements CommandExecutor, TabCompleter {

    private final GuardianAC plugin;

    public AnticheatCommand(GuardianAC plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("guardianac.admin")) {
            sender.sendMessage(ChatColor.RED + "Sizda ruxsat yo'q.");
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(ChatColor.GOLD + "/gac reload | check <player> | vl <player> | reset <player>");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage(ChatColor.GREEN + "[GuardianAC] Config qayta yuklandi.");
            }
            case "check", "vl" -> {
                if (args.length < 2) {
                    sender.sendMessage(ChatColor.RED + "Foydalanish: /gac " + args[0] + " <player>");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    sender.sendMessage(ChatColor.RED + "O'yinchi topilmadi yoki oflayn.");
                    return true;
                }
                PlayerData data = plugin.getViolationManager().getData(target);
                sender.sendMessage(ChatColor.GOLD + "=== " + target.getName() + " uchun VL ===");
                for (PlayerData.CheckType type : PlayerData.CheckType.values()) {
                    sender.sendMessage(ChatColor.GRAY + "- " + type.name() + ": " + ChatColor.YELLOW + data.getVl(type));
                }
            }
            case "reset" -> {
                if (args.length < 2) {
                    sender.sendMessage(ChatColor.RED + "Foydalanish: /gac reset <player>");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    sender.sendMessage(ChatColor.RED + "O'yinchi topilmadi yoki oflayn.");
                    return true;
                }
                plugin.getViolationManager().getData(target).resetAll();
                plugin.getPunishmentManager().resetStages(target.getUniqueId());
                sender.sendMessage(ChatColor.GREEN + target.getName() + " uchun barcha VL lar tozalandi.");
            }
            default -> sender.sendMessage(ChatColor.RED + "Noma'lum subcommand. /gac reload | check | vl | reset");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("reload", "check", "vl", "reset").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 2 && List.of("check", "vl", "reset").contains(args[0].toLowerCase())) {
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
            return names;
        }
        return List.of();
    }
}
